export { program } from 'commander';

/** @runcanon/cli - programmatic API */
declare const name = "@runcanon/cli";
declare const version = "0.1.0";

export { name, version };
