#!/usr/bin/env node
export { name, version } from './index.cjs';
import 'commander';

declare function initializeProject(projectPath: string): Promise<void>;
declare function runMine(options: {
    project?: string;
    dryRun?: boolean;
    trajectories?: string;
    sources?: string[];
}): Promise<void>;
declare function runReview(options: {
    project?: string;
    autoApprove?: boolean;
}): Promise<void>;
declare function runExport(options: {
    project?: string;
    harness: string;
}): Promise<void>;

export { initializeProject, runExport, runMine, runReview };
